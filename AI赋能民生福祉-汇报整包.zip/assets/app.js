
(function () {
"use strict";

/* =========================================================
   0. 基础工具
   ========================================================= */
const $  = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const HAS = (s) => !!document.querySelector(s);   /* 多页面：元素可能不在本页 */
const KEY = "aiwel:";
const store = {
  get(k, d) { try { const v = localStorage.getItem(KEY + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(KEY + k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem(KEY + k); } catch (e) {} }
};
let toastTimer = null;
function toast(msg) {
  const el = $("#toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
function nowStr() {
  const d = new Date(), p = (n) => (n < 10 ? "0" : "") + n;
  return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
}
function maskName(n) {
  n = (n || "").trim();
  if (!n) return "匿名体验官";
  if (n.length === 1) return n + "**";
  return n[0] + "*".repeat(Math.min(3, n.length - 1));
}
/* 敏感信息过滤（亲子内容保护） */
const SENS = [
  { re: /(1[3-9]\d{9})/g, to: "【手机号已隐藏】" },
  { re: /(\d{17}[\dXx])/g, to: "【证件号已隐藏】" },
  { re: /([一-龥]{2,10}(省|市|区|县|镇|街道|路|街|巷|小区|花园|苑|村)[一-龥0-9]{0,12}[号栋幢单元室]?)/g, to: "【住址已隐藏】" },
  { re: /([一-龥0-9]{2,12}(幼儿园|小学|中学|学校|附小|实小)[一-龥0-9]{0,8}(班|年级|中班|大班|小班)?)/g, to: "【学校班级已隐藏】" }
];
function filterText(t) {
  let out = String(t || ""), hit = false;
  SENS.forEach((r) => { if (r.re.test(out)) { hit = true; out = out.replace(r.re, r.to); } r.re.lastIndex = 0; });
  return { text: out, hit: hit };
}

/* =========================================================
   1. 无障碍设置（大字 / 高对比 / 减少动画 / 朗读）
   ========================================================= */
const A11Y = store.get("a11y", { fs: 0, hc: false, motion: false });
function applyA11y() {
  const h = document.documentElement;
  h.classList.remove("big1", "big2", "big3");
  if (A11Y.fs === 1) h.classList.add("big1");
  if (A11Y.fs === 2) h.classList.add("big2");
  if (A11Y.fs >= 3) h.classList.add("big3");
  h.classList.toggle("hc", !!A11Y.hc);
  h.classList.toggle("reduce-motion", !!A11Y.motion);
  $("#btnHC").setAttribute("aria-pressed", String(!!A11Y.hc));
  $("#btnMotion").setAttribute("aria-pressed", String(!!A11Y.motion));
  store.set("a11y", A11Y);
}
$("#fsUp").addEventListener("click", () => {
  A11Y.fs = Math.min(3, A11Y.fs + 1); applyA11y();
  toast(A11Y.fs === 3 ? "已切换到最大字号" : "字号已增大（" + (A11Y.fs + 1) + "/4 档）");
});
$("#fsDown").addEventListener("click", () => {
  A11Y.fs = Math.max(0, A11Y.fs - 1); applyA11y();
  toast(A11Y.fs === 0 ? "已恢复标准字号" : "字号已减小（" + (A11Y.fs + 1) + "/4 档）");
});
$("#btnHC").addEventListener("click", () => { A11Y.hc = !A11Y.hc; applyA11y(); toast(A11Y.hc ? "高对比度模式已开启" : "高对比度模式已关闭"); });
$("#btnMotion").addEventListener("click", () => { A11Y.motion = !A11Y.motion; applyA11y(); toast(A11Y.motion ? "已减少动画与闪烁" : "已恢复动画效果"); });
$("#btnReset").addEventListener("click", () => {
  A11Y.fs = 0; A11Y.hc = false; A11Y.motion = false; applyA11y();
  if (window.speechSynthesis) { try { speechSynthesis.cancel(); } catch (e) {} }
  $("#btnRead").setAttribute("aria-pressed", "false");
  toast("显示设置已恢复默认");
});
/* 语音朗读：朗读当前可视板块 */
let reading = false;
function currentSection() {
  const mid = window.scrollY + window.innerHeight * 0.35;
  let cur = null;
  $$("main section[id]").forEach((s) => { if (s.offsetTop <= mid) cur = s; });
  return cur || $("main section[id]");
}
$("#btnRead").addEventListener("click", () => {
  if (!("speechSynthesis" in window)) { toast("当前浏览器不支持语音朗读"); return; }
  if (reading) { speechSynthesis.cancel(); reading = false; $("#btnRead").setAttribute("aria-pressed", "false"); return; }
  const sec = currentSection();
  if (!sec) return;
  const h = sec.querySelector("h1,h2");
  const lede = sec.querySelector(".lede");
  const cards = $$(".card h3, .task h4, .tool h3", sec).slice(0, 4).map((n) => n.textContent).join("；");
  const text = [h ? h.textContent : "", lede ? lede.textContent : "", cards ? "本板块包括：" + cards : ""].join("。");
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "zh-CN"; u.rate = 0.95;
  u.onend = () => { reading = false; $("#btnRead").setAttribute("aria-pressed", "false"); };
  speechSynthesis.cancel(); speechSynthesis.speak(u);
  reading = true; $("#btnRead").setAttribute("aria-pressed", "true");
  toast("正在朗读：" + (h ? h.textContent : "当前板块"));
});
applyA11y();

/* =========================================================
   2. 儿童隐私同意（亲子板块门禁）
   ========================================================= */
const consent = { kid: store.get("consentKid", false) };
const dlg = $("#privacyDlg");
let pendingAction = null;
function requireKidConsent(fn) {
  if (consent.kid) { fn(); return; }
  pendingAction = fn;
  if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
}
$("#privacyYes").addEventListener("click", () => {
  consent.kid = true; store.set("consentKid", true);
  if (typeof dlg.close === "function") dlg.close(); else dlg.removeAttribute("open");
  toast("已确认，可查看亲子类内容");
  if (pendingAction) { const f = pendingAction; pendingAction = null; f(); }
});
$("#privacyNo").addEventListener("click", () => {
  pendingAction = null;
  if (typeof dlg.close === "function") dlg.close(); else dlg.removeAttribute("open");
  toast("已取消，继续浏览其他板块");
});
if (HAS("#openPrivacy")) $("#openPrivacy").addEventListener("click", () => {
  pendingAction = null;
  if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
});

/* 使用说明弹窗 */
const gdlg = $("#guideDlg");
if (HAS("#openGuide")) $("#openGuide").addEventListener("click", () => { if (typeof gdlg.showModal === "function") gdlg.showModal(); else gdlg.setAttribute("open", ""); });
$("#guideClose").addEventListener("click", () => { if (typeof gdlg.close === "function") gdlg.close(); else gdlg.removeAttribute("open"); });

/* =========================================================
   3. 通用：Tab 切换
   ========================================================= */
function bindTabs(container, attr, onSwitch) {
  const tabs = $$("[" + attr + "]", container);
  tabs.forEach((t) => t.addEventListener("click", () => {
    const need = t.getAttribute("data-need-consent");
    const go = () => {
      tabs.forEach((x) => { x.setAttribute("aria-selected", String(x === t)); });
      onSwitch(t.getAttribute(attr), t);
    };
    if (need) requireKidConsent(go); else go();
  }));
}
function tabGroup(selector, attr, onSwitch) { bindTabs($(selector), attr, onSwitch); }


function initClassroom() {/* =========================================================
   4. 板块 01 · 实训课堂
   ========================================================= */
const COURSES = {
  kid: [
    { t: "AI 早教陪伴", tag: "k", learn: "用 AI 讲睡前故事、认物识色、做亲子问答，把碎片时间变成陪伴时间。",
      steps: ["选一个儿童内容模式的故事/问答工具", "设定主题（动物、自然、礼貌习惯）", "和孩子一起复述、提问，不让孩子单独对话"],
      care: "单次不超过 20 分钟；关闭个性化推荐；不上传孩子照片与声音。",
      demo: "演示输出（AI 生成）：「小兔子点点今天学会了排队——排队不是等，是给每个人留一个位置。宝宝，你在幼儿园排队时排第几个呀？」" },
    { t: "AI 习惯纠正", tag: "k", learn: "用打卡表 + AI 生成的鼓励话术，帮孩子建立刷牙、整理玩具、按时睡觉的习惯。",
      steps: ["列出 3 个本周小目标", "让 AI 生成一张图文打卡表", "完成即贴纸，家长口头肯定优先于物质奖励"],
      care: "不用 AI 做「监控式管教」，避免把成长变成打分游戏。",
      demo: "演示输出（AI 生成）：本周打卡表 —— ① 早晚刷牙 ② 玩具回家 ③ 21:00 上床。奖励：周末和爸爸一起做一次手工。" },
    { t: "安全育儿筛查", tag: "k", learn: "用 AI 快速核查玩具适用年龄、食品成分表、家庭用药禁忌，降低看护风险。",
      steps: ["拍照或输入商品名/成分", "让 AI 标注风险点与适用年龄", "以说明书与医生意见为最终依据"],
      care: "AI 结论仅供参考，用药与就医必须遵医嘱。",
      demo: "演示输出（AI 提醒）：该玩具标注 3+，含小零件，家中有 2 岁以下幼儿时需收纳在儿童不可及处。" },
    { t: "AI 亲子阅读", tag: "k", learn: "把绘本故事改成孩子听得懂的话，生成互动提问，读完一起复述。",
      steps: ["输入绘本名称或一段原文", "让 AI 生成 3 个启发式提问", "读完请孩子讲给你听"],
      care: "保留纸质书阅读时间，屏幕只是补充。",
      demo: "演示输出（AI 提问）：① 小熊为什么要把蜂蜜分给大家？② 如果你是小熊，你会怎么做？③ 你有过分享的经历吗？" }
  ],
  youth: [
    { t: "AI 写文案", tag: "y", learn: "活动推文、社团招新、简历自述、短视频脚本——用 AI 打初稿，自己改灵魂。",
      steps: ["说清对象、场景、字数、语气", "让 AI 出 2~3 个版本并对比", "人工核对事实、补充自己的真实经历"],
      care: "AI 可能编造数据与引语，发布前务必核实；作业/作品按学校要求标注 AI 使用情况。",
      demo: "演示输出（AI 初稿）：标题《把周末还给阅读》——开头：图书馆的灯亮到几点，城市的思考就走到多远。" },
    { t: "AI 做设计", tag: "y", learn: "海报、封面、PPT 版式、配图灵感，用 AI 生成草图再手工精修。",
      steps: ["确定主题色与尺寸", "生成 3 版构图并挑一版", "替换字体、校准版权素材"],
      care: "不使用未授权素材；不生成他人肖像与仿冒品牌标识。",
      demo: "演示输出（提示词示例）：公益科普海报，暖橙+米白，主标题「AI 普惠民生」，留白 40%，扁平插画风。" },
    { t: "AI 学技能", tag: "y", learn: "把大目标拆成 30 天学习路径，用 AI 当陪练：出题、纠错、解释。",
      steps: ["写明基础水平与每天可用时间", "让 AI 输出周计划 + 每日练习", "每周复盘，错题让 AI 讲思路而不是给答案"],
      care: "先自己做题再看解析；别让 AI 替你完成作业。",
      demo: "演示输出（AI 计划）：第 1 周 Python 基础语法 → 每日 30 分钟练习 → 周末做一个「成绩统计小工具」。" },
    { t: "AI 求职辅助", tag: "y", learn: "岗位匹配、简历优化、模拟面试、作品集整理。",
      steps: ["粘贴岗位要求 + 你的经历", "让 AI 找出差距并改写简历要点", "用 AI 做 3 轮模拟面试并复盘"],
      care: "简历内容必须真实，不夸大实习与成果；不向 AI 提交身份证号、银行卡等敏感信息。",
      demo: "演示输出（AI 反馈）：你的简历缺少量化成果，建议把「参与项目」改写为「负责 X 模块，覆盖 Y 人，效率提升 Z%」。" }
  ],
  elder: [
    { t: "AI 查健康", tag: "e", learn: "用官方平台的智能客服查医保、查报告、问用药常识。",
      steps: ["打开国家医保服务平台或医院官方小程序", "用语音输入问题（普通话慢一点）", "以医生与官方答复为准"],
      care: "AI 不能诊断与开药；出现急症立即就医或拨打 120。",
      demo: "演示输出（AI 答复）：您咨询的慢病续方可在「医保服务平台→我的→慢病管理」中申请，最终以医院审核为准。" },
    { t: "视频通话教学", tag: "e", learn: "一步步学会和子女视频：连 Wi-Fi、开微信、点视频通话、调大音量。",
      steps: ["把 App 图标放在手机首屏", "打开微信→选联系人→点「+」→视频通话", "接不到就把手机音量键调大、靠近路由器"],
      care: "陌生链接不要点；自称子女借钱一定电话核实。",
      demo: "演示输出（教学口诀）：先连网、再找人、按加号、点视频；看不清就双指放大屏幕。" },
    { t: "AI 反诈防骗", tag: "e", learn: "识别 AI 换脸、AI 拟声、假客服、假中奖四类常见骗局。",
      steps: ["听到熟人借钱先挂断再回拨", "涉及转账一律与子女当面确认", "用国家反诈中心 App 举报可疑号码"],
      care: "视频里的人也可能是假的——让对方做一个随机动作（如侧脸、报一个家里的小秘密）。",
      demo: "演示输出（AI 提醒）：「您的医保卡异常」类来电多为诈骗，官方不会通过电话索要验证码。" },
    { t: "智能居家使用", tag: "e", learn: "语音开灯、智能音箱提醒吃药、烟感/燃气报警器联动。",
      steps: ["选带语音控制与实体按键的设备", "设好「吃药提醒」与「紧急联系人」", "每月测试一次报警与呼叫"],
      care: "不把门锁与摄像头权限交给陌生 App；设备密码不要用生日。",
      demo: "演示输出（场景示例）：「小爱同学，晚上 8 点提醒我吃降压药」→ 到点播报 + 给子女推送一条已服药提醒。" }
  ]
};
function courseCard(c) {
  const cls = c.tag === "k" ? "t-kid" : c.tag === "y" ? "t-youth" : "t-elder";
  const name = c.tag === "k" ? "幼儿启蒙" : c.tag === "y" ? "青年成长" : "老年保障";
  const aud = c.tag === "k" ? "kid" : c.tag === "y" ? "youth" : "elder";
  return '<article class="card" data-aud="' + aud + '">' +
    '<span class="tag ' + cls + '">' + name + "</span>" +
    "<h3 style=\"margin-top:.5rem\">" + esc(c.t) + "</h3>" +
    "<p style=\"font-size:.94rem;color:var(--ink-2);margin-bottom:.5rem\">" + esc(c.learn) + "</p>" +
    "<dl class=\"kv\"><dt>怎么用</dt><dd>" + c.steps.map((s) => esc(s)).join("<br>") + "</dd>" +
    "<dt>注意</dt><dd>" + esc(c.care) + "</dd></dl>" +
    '<div style="margin-top:.8rem"><button class="btn btn-ghost btn-sm demoBtn" type="button">试一试（演示）</button></div>' +
    '<p class="demoOut muted" style="margin:.6rem 0 0;display:none"></p>' +
    '<span class="demoData" hidden>' + esc(c.demo) + "</span></article>";
}
function fillCourses() {
  $("#kidCourses").innerHTML = COURSES.kid.map(courseCard).join("");
  $("#youthCourses").innerHTML = COURSES.youth.map(courseCard).join("");
  $("#elderCourses").innerHTML = COURSES.elder.map(courseCard).join("");
  $$(".demoBtn").forEach((b) => b.addEventListener("click", () => {
    const card = b.closest(".card"), out = $(".demoOut", card);
    out.textContent = $(".demoData", card).textContent;
    out.style.display = "block";
  }));
}
tabGroup(".tabs[aria-label='实训课堂分组']", "data-cls", (v) => {
  $("#paneKid").hidden = v !== "kid";
  $("#paneYouth").hidden = v !== "youth";
  $("#paneElder").hidden = v !== "elder";
  if (v === "kid") requireKidConsent(() => {});
});



  fillCourses();}

function initHall() {/* =========================================================
   5. 板块 02 · 案例展厅
   ========================================================= */
const HALLS = [
  {
    key: "elder", name: "银发生活馆", no: "HALL 01",
    sub: "体检、居家、屏幕、骗局——老人日常生活里最具体的四道坎",
    facts: [
      "2025 年底，我国 60 岁及以上老年人口 3.2 亿，约 90% 选择居家养老（央视网，2026-10-18）",
      "工信部累计遴选推广 8 批次共 1700 余项适老产品与服务（央视网，2026-10-18）",
      "工信部、民政部已确定 32 个智能养老服务机器人结对攻关与场景应用试点项目（央视网，2026-10-18）"
    ],
    items: [
      { t: "在家门口 10 分钟做完体检", who: "广西柳州 · 春风社区数智康养中心",
        pain: "78 岁的李爷爷以前做一次体检，要子女专门请假陪着去医院，来回大半天；80 多岁的张奶奶一开始怕自己不会摆弄机器，站在门口不敢进。",
        fix: "社区把检查设备搬到家门口，10 分钟就能做完，设备还会直接给出「少吃盐、多散步」这样的大白话提醒。工作人员现场讲一遍，张奶奶一次就学会了，如今每周都来，还带着同伴一起来。中心定期开「科技小课堂」教老人用手机看健康数据，下一步打算给设备加上语音提示，让视力不好的老人也能自己操作。",
        src: "全国中老年网《搭建数智康养场景 守护「银发生活」》。文中另提到，柳州市 78 家长者饭堂、32 家社区养老服务场所已引入相关产品。" },
      { t: "摔倒的那几秒，摄像头先叫了人", who: "广西柳州 · 市社会福利院",
        pain: "肖奶奶需要长期康复训练，因为怕摔倒没人发现，一直不肯用助行器；护理员大部分时间耗在巡查和记录上，很难腾出手陪老人说说话。",
        fix: "院里装了能识别身体失衡的 AI 视频监控。肖奶奶有一次用助行器起身时滑倒，警报立刻响起，信息同步推到护士站电脑并在楼层播报，护理员很快赶到。同时配了智能床垫测睡眠、手环测心率血压。护理员说，现在不用劝，老人会主动按时训练，自己也能多陪他们一会儿——从「忙着巡查」变成了「从容陪伴」。",
        src: "全国中老年网同上。报道中提到除跌倒监测外，已引入智能床垫与手环等设备。" },
      { t: "把大字、语音和医保购药装进家里那块屏", who: "浙江 · 适老化智家 AI 中屏；中国广电 APP 关怀版",
        pain: "老人看不清手机上的小字，查个话费余额、买个药都要等孩子回来帮忙；说方言还常常被语音助手听错。",
        fix: "中国联通浙江分公司做了 10 英寸家庭桌面终端，把看电视、语音查天气、医保购药、全域语音交互放在一起，老人张嘴说就行；中国广电在官方 APP 里单独做了「关怀版」界面，放大字体、只留最常用的功能，截至 2026 年 9 月底已覆盖 222 万户。中国联通还专门开设方言坐席，让老人用自己的话讲需求。",
        src: "中国工信新闻网《数字适老中国行》（2026-10-20）。中国广电关怀模式覆盖用户 222 万户。" },
      { t: "拦下来的那通电话，也是一条战绩", who: "腾讯客服银龄服务基地",
        pain: "AI 换脸、语音合成、虚假理财——骗局的样子变得快，老人往往在「熟人」开口的那一刻就信了。",
        fix: "基地依托大模型构建「全链路、负责任、可迭代」的银发服务体系：反诈助手持续学习新型诈骗手法，动态更新风险模型，做 7×24 小时智能筛查。截至目前，累计人工拦截劝阻潜在受骗老人 3.2 万人次。同时各地常态化开「银龄数字课堂」，把反诈知识讲到老人身边。",
        src: "中国工信新闻网《数字适老中国行》（2026-10-20）。3.2 万人次为报道中披露的累计数。" }
    ]
  },
  {
    key: "youth", name: "青年成长馆", no: "HALL 02",
    sub: "从一门能考证的手艺，到夜校里的一张课桌",
    facts: [
      "2026 年 1—5 月，新发校招 AI 岗位量同比增长 47.3%（脉脉高聘人才智库，人社部网站引述）",
      "近 5 年人社部发布的新职业中，逾 20 个与人工智能紧密相关（人社部，2026-07-15）",
      "「十五五」期间力争每年开展补贴性职业技能培训 1000 万人次（央视网，2026-10-11）"
    ],
    items: [
      { t: "离开职场多年后，她拿到了月薪 6000 的offer", who: "湖南永州 · 潘峥霖（健康照护师）",
        pain: "潘峥霖离开职场多年，找工作一直不顺利，投出去的简历大多没有回音——技能与市场对不上，是很多年轻人卡住的地方。",
        fix: "她在「永州发布」公众号上看到政府组织的技能培训，报名了健康照护师订单班，结业后进入当地一家养老服务公司，为失能老人做生活护理，月薪 6000 元。永州的做法是「群众点单、人社派单、机构接单、企业订单」，围绕人工智能训练师、无人机驾驶员等紧缺工种组织培训，2026 年上半年培训 1.1 万人次，已有 5000 余人顺利就业。",
        src: "教育部网站《推动高质量充分就业取得新进展》（2026-08-10）。" },
      { t: "AI 训练师：一门能考出证书的新手艺", who: "上海 · 人工智能训练师职业技能等级评价",
        pain: "年轻人知道 AI 火，但不知道该学什么、学到什么程度才算数，简历上写「熟悉 AI」又拿不出凭据。",
        fix: "2025 年上海有 1.63 万人次参加人工智能训练师职业技能等级评价，1.09 万人通过评价拿到职业资格等级证书。人社部近年发布的新职业里，人工智能训练师、生成式人工智能系统应用员、人工智能数字人训练师等陆续出现，让「会用 AI」有了可衡量的台阶。",
        src: "人力资源社会保障部《让 AI 技能成为青年职场护城河》（2026-07-15）。" },
      { t: "夜校里的 AI 课，下了班就能去", who: "江苏、北京、广东、宁夏 · 「AI 夜校」与专项培训",
        pain: "想学但报不起长期班，也不确定学完能干什么——这是很多在职青年的顾虑。",
        fix: "江苏启动「人工智能+」技术技能专项培训行动，计划每年面向全社会开展人工智能领域培训超 20 万人次；北京、广东、宁夏等地办起「AI 夜校」，把课开进社区。广东在世界青年技能日主题活动里设了全天开放的体验学堂，零基础市民在指导下学 AI 直播、体验智能机器人。截至 2025 年，全国共有技工院校 2410 所、在校生 419 万人，全年开展职业技能培训 569.5 万人次。",
        src: "人力资源社会保障部《让 AI 技能成为青年职场护城河》（2026-07-15）。" },
      { t: "AI 进了课表，也进了就业清单", who: "教育部等五部门 · 「人工智能+教育」行动计划",
        pain: "高校课程更新慢，学生毕业时学的和岗位要的常常不是一回事。",
        fix: "2026 年 4 月 10 日，教育部等五部门启动「人工智能+教育」行动计划：人工智能将成为高校公共基础课，按学科专业分类编写教材；把人工智能纳入高校学生就业能力提升「双千」计划，鼓励开设微专业课程和微证书项目。「十五五」期间，国家还将面向全体劳动者开展人工智能通识教育，面向从业者开展数字工程师培育。",
        src: "教育部《「人工智能+教育」行动计划启动》（2026-04-10）；央视网《「十五五」时期我国将出台多项举措 拓宽青年就业渠道》（2026-10-11）。" }
    ]
  },
  {
    key: "parent", name: "亲子启蒙馆", no: "HALL 03",
    sub: "先划清红线，再谈怎么用——孩子用 AI 的边界与家长的分寸",
    facts: [
      "0—3 岁婴幼儿不建议直接接触人工智能工具、玩具及人工智能生成内容（北京市教委，2026 版《指南》）",
      "3—6 岁儿童不得使用拟人化情感陪伴类应用，防止形成依赖（同上）",
      "小学阶段学生不建议独自使用人工智能工具（同上）"
    ],
    items: [
      { t: "不同年龄，不同的红线", who: "北京市教委《北京市教育领域人工智能应用指南（2026 年）》",
        pain: "市面上的通用大模型不分年龄、不分场景开放，家长拿不准：到底几岁能碰？能碰多久？",
        fix: "《指南》按学段给出边界：0—3 岁不建议直接接触 AI 工具、玩具及 AI 生成内容；3—6 岁可在家长陪伴下，在音乐、美术等领域有限体验，其余场景不建议使用，且不得使用拟人化情感陪伴类应用；小学阶段不建议独自使用，可在教师辅助教学时适当使用；初中可在陪伴下适度探索，高中可在教师许可下结合技术原理开展探究性学习。同时要求面向未成年人制定单独的隐私政策，处理相关信息须征得监护人明示同意。",
        src: "中国青年网（2026-09-21）、央视网（2026-09-30）、北京市人民政府网站（2026-10-02）相关报道。" },
      { t: "「6 天开出一家 AI 公司」的研学营", who: "暑期 AI 研学营与 AI 学习机市场",
        pain: "机构打出「8 岁当产品经理，13 岁创业当老板」的宣传，课程标价动辄数千元乃至上万元；AI 学习机打着「AI 精准学」「AI 一对一」卖点热销，家长很难判断值不值。",
        fix: "研发人员在报道中直言：重营销、轻实操是普遍现象，不少课程停留在 AI 生成文案、做 PPT 这类浅层工具使用，不具备专业教研能力，行业标准尚未健全、收费虚高。给家长的判断方法很朴素——看课程是不是让孩子动手做、有没有真实产出，而不是看宣传语有多响。",
        src: "人民网《孩子写作业先问 AI，家长怎么办》（2026-09-03）。" },
      { t: "比「会不会用」更重要的四种能力", who: "一线教师与专家的四条建议",
        pain: "孩子拿到 AI 就直接抄答案，家长最怕的是「脑子不用了」。",
        fix: "老师徐琳提出四种能力：提问力（好问题比好答案珍贵）、判断力（辨别 AI 输出里的偏见与错误）、整合力（把 AI 检索到的信息与自己的经验、价值观结合）、反思力（追问 AI 帮了什么、限制了什么）。实操上分年龄段推进：小学阶段就同一问题向 AI 多问几次，观察每次答案的差异，培养质疑习惯；中学阶段要求附上「我的思考轨迹」；所有阶段都强调线下检验——AI 给的菜谱要真的下厨做一遍，AI 写的代码要亲自运行一次。",
        src: "人民网《孩子写作业先问 AI，家长怎么办》（2026-09-03）。" },
      { t: "家里那张「AI 使用公约」", who: "家校社协同的分工",
        pain: "家长想管，但不知道管什么、怎么管，常常要么一刀切禁止，要么完全放手。",
        fix: "《指南》鼓励家长结合学段特点，和孩子一起设计「家庭 AI 使用公约」并细化条款；家长履行未成年人 AI 使用的法定监护责任，合理管控时长与应用场景。学校方面要提前声明作业中可以使用和不能使用 AI 的范围，避免「一刀切」；教师使用 AI 辅助教学时应始终发挥育人主导作用。专家同时提醒：要警惕 AI 变成更精准、更隐蔽的应试训练工具。",
        src: "北京市人民政府网站（2026-10-02）；人民网《孩子写作业先问 AI，家长怎么办》（2026-09-03）。" }
    ]
  }
];
const HALL_KEYS = HALLS.map((h) => h.key);
function buildHall() {
  $("#hallRing").innerHTML = HALLS.map((h, i) =>
    '<section class="wing" data-i="' + i + '" data-k="' + h.key + '" role="tabpanel" aria-label="' + esc(h.name) + '" data-aud="' + (h.key === "parent" ? "kid" : h.key) + '">' +
    '<div class="wing-head"><h3>' + esc(h.name) + '</h3><span class="sub">' + esc(h.sub) + '</span><span class="no">' + esc(h.no) + "</span></div>" +
    '<ul style="margin:0 0 .7rem;padding-left:1.05rem;font-size:.8rem;color:var(--ink-2)">' +
    h.facts.map((f) => "<li style=\"margin-bottom:.15rem\">" + esc(f) + "</li>").join("") + "</ul>" +
    '<div class="wing-grid">' + h.items.map((it, j) =>
      '<article class="exh"><span class="who">' + esc(it.who) + "</span>" +
      "<h4>" + String(j + 1).padStart(2, "0") + "　" + esc(it.t) + "</h4>" +
      '<p class="pain"><b>遇到的难处：</b>' + esc(it.pain) + "</p>" +
      '<p class="fix"><b>AI 怎么帮上忙：</b>' + esc(it.fix) + "</p>" +
      '<p class="src"><b>出处：</b>' + esc(it.src) + "</p></article>").join("") +
    "</div></section>").join("");
}
let hallAngle = 0, hallKey = "elder";
function showHall(key, keepSpin) {
  const idx = HALL_KEYS.indexOf(key); if (idx < 0) return;
  const target = -idx * 120;
  let delta = ((target - hallAngle) % 360 + 540) % 360 - 180;
  if (keepSpin === false) delta = 0;
  hallAngle = hallAngle + delta;
  hallKey = key;
  const ring = $("#hallRing");
  ring.style.setProperty("--ry", hallAngle + "deg");
  $$(".hbtn[data-case]").forEach((b) => b.setAttribute("aria-selected", String(b.getAttribute("data-case") === key)));
  $$(".wing").forEach((w, i) => {
    const on = HALLS[i].key === key, flat = $("#hall").classList.contains("flat");
    if ("inert" in w) w.inert = !on && !flat;
    w.setAttribute("aria-hidden", String(!on && !flat));
  });
}
function hallByAngle(a) {
  let idx = Math.round(-a / 120) % 3; if (idx < 0) idx += 3;
  return HALL_KEYS[idx];
}
function hallGo(step) {
  const idx = HALL_KEYS.indexOf(hallKey);
  let next = (idx + step + 3) % 3;
  const tryGo = () => showHall(HALL_KEYS[next]);
  if (HALL_KEYS[next] === "parent" && !consent.kid) requireKidConsent(tryGo); else tryGo();
}
$$(".hbtn[data-case]").forEach((b) => b.addEventListener("click", () => {
  const k = b.getAttribute("data-case");
  const go = () => showHall(k);
  if (k === "parent" && !consent.kid) requireKidConsent(go); else go();
}));
$("#hallPrev").addEventListener("click", () => hallGo(-1));
$("#hallNext").addEventListener("click", () => hallGo(1));
$("#hallFlat").addEventListener("click", () => {
  const h = $("#hall"), on = !h.classList.contains("flat");
  h.classList.toggle("flat", on);
  $("#hallFlat").setAttribute("aria-pressed", String(on));
  $$(".wing").forEach((w, i) => { const on2 = on || HALLS[i].key === hallKey; if ("inert" in w) w.inert = !on2; w.setAttribute("aria-hidden", String(!on2)); });
  toast(on ? "已切换为平面浏览，三个展区依次排列" : "已返回 3D 展厅");
});
/* 拖动转动视角 */
(function () {
  const stage = $("#hallStage"), ring = $("#hallRing");
  let dragging = false, sx = 0, sa = 0, moved = 0;
  stage.addEventListener("pointerdown", (e) => {
    if ($("#hall").classList.contains("flat")) return;
    dragging = true; moved = 0; sx = e.clientX; sa = hallAngle;
    ring.classList.add("notrans"); stage.classList.add("dragging");
    stage.setPointerCapture && stage.setPointerCapture(e.pointerId);
  });
  stage.addEventListener("pointermove", (e) => {
    if (!dragging) return;
    moved = Math.abs(e.clientX - sx);
    hallAngle = sa + (e.clientX - sx) * 0.32;
    ring.style.setProperty("--ry", hallAngle + "deg");
  });
  const end = () => {
    if (!dragging) return;
    dragging = false; ring.classList.remove("notrans"); stage.classList.remove("dragging");
    const snap = Math.round(hallAngle / 120) * 120;
    hallAngle = snap;
    ring.style.setProperty("--ry", hallAngle + "deg");
    const k = hallByAngle(snap);
    if (k !== hallKey) { if (k === "parent" && !consent.kid) requireKidConsent(() => showHall("parent")); else showHall(k); }
    else showHall(k);
  };
  stage.addEventListener("pointerup", end);
  stage.addEventListener("pointercancel", end);
  stage.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") { e.preventDefault(); hallGo(-1); }
    if (e.key === "ArrowRight") { e.preventDefault(); hallGo(1); }
  });
})();
const CASE_SOURCES = [
  ["央视网", "《九九重阳节·银发新图景观察：智慧养老让「老有所安」》", "2026-10-18"],
  ["人民网北京频道", "《国企存量院落「适老新生」 AI 机器人「上岗」》", "2026-10-15"],
  ["中国工信新闻网", "《数字适老中国行：数字适老助银龄乐享数智生活》", "2026-10-20"],
  ["全国中老年网", "《搭建数智康养场景 守护「银发生活」》", "柳州数智康养试点"],
  ["中华人民共和国教育部", "《「人工智能+教育」行动计划启动》", "2026-04-10"],
  ["人力资源社会保障部", "《让 AI 技能成为青年职场护城河》", "2026-07-15"],
  ["央视网", "《「十五五」时期我国将出台多项举措 拓宽青年就业渠道》", "2026-10-11"],
  ["中华人民共和国教育部", "《推动高质量充分就业取得新进展》", "2026-08-10"],
  ["中国青年网 / 央视网", "《北京发布 2026 版教育领域人工智能应用指南》", "2026-09"],
  ["人民网教育频道", "《孩子写作业先问 AI，家长怎么办》", "2026-09-03"]
];
$("#caseSources").innerHTML = '<ul style="margin:.3rem 0 0;padding-left:1.1rem;font-size:.84rem;line-height:1.7">' +
  CASE_SOURCES.map((s) => "<li>" + esc(s[0]) + "　" + esc(s[1]) + "　<span style=\"color:var(--ink-3)\">" + esc(s[2]) + "</span></li>").join("") + "</ul>";



  buildHall(); showHall("elder", false);}

function initCommunity() {/* =========================================================
   6. 板块 03 · 交流社区
   ========================================================= */
const SEED_POSTS = {
  youth: [
    { nick: "小林", role: "青年", text: "用 AI 帮我改简历，把「参与项目」改成「负责用户调研，回收 320 份问卷」，面试邀约明显多了。提醒：数据必须是真的，编的一问就露馅。", like: 12, t: "2 天前" },
    { nick: "阿May", role: "青年", text: "做社团招新海报，AI 出了 3 版构图，我选了一版重画字体。省时间，但审美还是得自己练。", like: 8, t: "3 天前" }
  ],
  parent: [
    { nick: "乐乐妈妈", role: "家长", text: "睡前让 AI 生成故事，我陪着一起讲，最后让娃自己编结局。孩子更爱讲了，但我会先看过内容再讲给他听。", like: 15, t: "1 天前" },
    { nick: "豆豆爸", role: "家长", text: "打卡表是 AI 做的，贴纸是我画的。孩子为了贴纸主动刷牙，比唠叨管用。", like: 9, t: "4 天前" }
  ],
  elder: [
    { nick: "王叔叔", role: "老年人", text: "学会视频通话后，每周和孙女「云吃饭」。我把图标放首屏，还让女儿给我设了快捷拨号。", like: 21, t: "2 天前" },
    { nick: "李阿姨", role: "老年人", text: "手机调成大字模式，又开了语音播报，看消息不费劲了。就是有的 App 字还是太小，希望都能改。", like: 17, t: "5 天前" }
  ]
};
let curChannel = "youth";
function getPosts(ch) { return store.get("posts:" + ch, null) || SEED_POSTS[ch] || []; }
function renderPosts() {
  const list = getPosts(curChannel);
  $("#postList").innerHTML = list.length ? list.map((p, i) =>
    '<article class="post"><div class="meta"><span class="who">' + esc(p.nick) + "</span>" +
    '<span class="tag ' + (curChannel === "parent" ? "t-kid" : curChannel === "youth" ? "t-youth" : "t-elder") + '">' + esc(p.role) + "</span>" +
    "<span>" + esc(p.t) + "</span></div><p>" + esc(p.text) + "</p>" +
    '<div class="acts"><button class="btn btn-ghost btn-sm likeBtn" type="button" data-i="' + i + '">同感</button>' +
    '<span class="likenum">' + p.like + " 人有同感</span>" +
    (isSeed(p) ? "" : '<button class="btn btn-ghost btn-sm delBtn" type="button" data-i="' + i + '">删除</button>') +
    "</div></article>").join("")
    : '<div class="empty">这个频道还没有内容，来说第一句吧。</div>';
  $$(".likeBtn", $("#postList")).forEach((b) => b.addEventListener("click", () => {
    const list2 = getPosts(curChannel); const i = +b.getAttribute("data-i");
    list2[i].like = (list2[i].like || 0) + 1; store.set("posts:" + curChannel, list2); renderPosts();
  }));
  $$(".delBtn", $("#postList")).forEach((b) => b.addEventListener("click", () => {
    const list2 = getPosts(curChannel); list2.splice(+b.getAttribute("data-i"), 1);
    store.set("posts:" + curChannel, list2); renderPosts(); toast("已删除该条内容");
  }));
}
function isSeed(p) { return SEED_POSTS[curChannel].indexOf(p) > -1; }
tabGroup(".tabs[aria-label='社区频道']", "data-ch", (v) => {
  curChannel = v; $("#kidFilterNote").hidden = v !== "parent"; renderPosts();
});
$("#postForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const raw = $("#pText").value.trim(); if (!raw) return;
  const role = ($("input[name='role']:checked") || {}).value || "青年";
  const nick = $("#pNick").value.trim() || (curChannel === "parent" ? "宝宝家长·匿名" : "热心网友");
  let text = raw, msg = "发布成功";
  if (curChannel === "parent") { const r = filterText(text); text = r.text; if (r.hit) msg = "发布成功（已自动隐藏敏感信息）"; }
  const list = getPosts(curChannel);
  list.unshift({ nick: nick, role: role, text: text, like: 0, t: "刚刚" });
  store.set("posts:" + curChannel, list);
  $("#pText").value = ""; $("#pCount").textContent = "0"; renderPosts(); toast(msg);
});
$("#pText").addEventListener("input", () => { $("#pCount").textContent = $("#pText").value.length; });
$("#clearPosts").addEventListener("click", () => {
  store.del("posts:" + curChannel); renderPosts(); toast("已清空本频道的本地内容（示例内容不会恢复）");
});



  renderPosts();}

function initFeedback() {/* =========================================================
   7. 板块 04/05 · 匿名反馈 + AI 解惑
   ========================================================= */
const SEED_FB = [
  { type: "踩坑", topic: "挂号就医", text: "用 AI 挂号助手，结果点进去全是广告，还让我开通会员才能预约。", like: 26 },
  { type: "困惑", topic: "AI 聊天问答", text: "问 AI 一个专业问题，它答得很流畅，但我在书上查到的结论不一样，到底信谁？", like: 22 },
  { type: "踩坑", topic: "AI 修图/换脸", text: "家里群转了个视频，说是亲戚借钱，脸和声音都很像，差点就转了。", like: 31 },
  { type: "困惑", topic: "求职简历", text: "AI 帮我润色简历，写得很好看，但我担心里面有夸大，面试被问到怎么办？", like: 18 },
  { type: "建议", topic: "语音助手", text: "我讲的是方言，语音助手总听不懂，希望多支持方言识别。", like: 20 },
  { type: "困惑", topic: "健康查询", text: "把体检报告发给 AI 问要不要紧，它说没事，我还是不放心。", like: 15 }
];
function getFb() {
  let list = store.get("fb", null);
  if (!list) { list = SEED_FB.map((x, i) => ({ id: "s" + i, type: x.type, topic: x.topic, text: x.text, like: x.like })); store.set("fb", list); }
  return list;
}
function renderFb() {
  const list = getFb().slice().sort((a, b) => (b.like || 0) - (a.like || 0));
  $("#fbTotal").textContent = list.length;
  $("#fbList").innerHTML = list.length ? list.map((f) =>
    '<article class="post"><div class="meta"><span class="who">匿名用户</span>' +
    '<span class="tag t-elder">' + esc(f.type) + "</span><span>场景：" + esc(f.topic) + "</span></div>" +
    "<p>" + esc(f.text) + "</p>" +
    '<div class="acts"><button class="btn btn-ghost btn-sm fbLike" type="button" data-id="' + f.id + '">同感</button>' +
    '<span class="likenum">' + (f.like || 0) + " 人有同感</span></div></article>").join("")
    : '<div class="empty">还没有反馈，来当第一个说话的人。</div>';
  $$(".fbLike").forEach((b) => b.addEventListener("click", () => {
    const id = b.getAttribute("data-id"), list2 = getFb();
    const target = list2.filter((x) => x.id === id)[0];
    if (target) { target.like = (target.like || 0) + 1; store.set("fb", list2); renderFb(); }
  }));
}
$("#fbForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const t = $("#fbText").value.trim(); if (!t) return;
  const list = getFb();
  list.unshift({ id: "u" + Date.now(), type: ($("input[name='fbtype']:checked") || {}).value || "踩坑", topic: $("#fbTopic").value, text: t, like: 0 });
  store.set("fb", list);
  $("#fbText").value = ""; $("#fbCount").textContent = "0"; renderFb();
  toast("已匿名提交，感谢你的反馈");
});
$("#fbText").addEventListener("input", () => { $("#fbCount").textContent = $("#fbText").value.length; });

/* AI 解惑：基于本地规则库整理高频问题 */
const KB = [
  { kw: ["挂号", "就医", "预约", "医院"], q: "AI 挂号会不会被带到广告页？", a: "只用医院官方小程序 / 官方 App 或政务平台入口；凡是要求先开通会员、付费插队、跳转外部链接的，一律退出。国家公立医院的预约本身不收费，遇到收费页面先找「人工窗口 / 电话预约」。" },
  { kw: ["换脸", "拟声", "借钱", "视频", "诈骗", "验证码"], q: "视频里是熟人，怎么确认不是 AI 换脸？", a: "挂断后用你原本存的号码回拨；让对方做随机动作（侧脸、遮半张脸、报出只有你们知道的小事）。凡是涉及转账、验证码、屏幕共享，先与家人当面确认，或拨打 96110 咨询。" },
  { kw: ["简历", "求职", "面试", "夸大"], q: "AI 润色简历会不会变成造假？", a: "可以优化表达，不能改变事实：时间、职责、数据必须真实。把「参与」改成量化成果时，数字要能被你自己解释清楚；面试前把每一条都准备一个真实案例。" },
  { kw: ["方言", "语音", "听不懂", "助手"], q: "方言识别不准怎么办？", a: "说慢一点、句子短一点、关键词加重；把常用指令设成快捷方式（如「打电话给女儿」）。选择支持方言的产品，并在反馈里提交你的方言样本建议——这就是体验官计划在做的事。" },
  { kw: ["健康", "体检", "报告", "用药", "病历"], q: "AI 看体检报告靠谱吗？", a: "可以看懂指标含义、准备就诊问题，但不能替代诊断。不要上传含身份证号、可识别人脸的病历原图；异常指标请挂对应科室，把 AI 的解释当成「和医生沟通的草稿」。" },
  { kw: ["会员", "付费", "套路", "广告", "扣费"], q: "怎么避开 AI 工具的付费套路？", a: "三看法则：看是否默认勾选续费、看免费额度是否够用、看取消路径是否容易。先用免费额度验证效果，再决定是否付费；不在小众站点绑定免密支付。" },
  { kw: ["幻觉", "不准", "编造", "信谁", "专业"], q: "AI 答错了怎么办？", a: "AI 会「一本正经地编造」，专业事实必须交叉验证（教材、官方文件、原始出处）。让它给出来源并自己点开核对；越是关键决策，越要把 AI 当助手而不是裁判。" },
  { kw: ["隐私", "照片", "上传", "信息"], q: "哪些信息绝对不能发给 AI？", a: "身份证号、银行卡号与验证码、病历原件、涉密与内部资料、他人肖像与隐私。发布前想一想：这条信息如果公开，我会不会后悔？" }
];
function genQA() {
  const list = getFb();
  const scored = KB.map((k) => {
    let s = 0;
    list.forEach((f) => { const hay = (f.text + f.topic + f.type); k.kw.forEach((w) => { if (hay.indexOf(w) > -1) s += (f.like || 0) + 1; }); });
    return { k: k, s: s };
  }).filter((x) => x.s > 0).sort((a, b) => b.s - a.s).slice(0, 4);
  const picks = scored.length ? scored.map((x) => x.k) : KB.slice(0, 4);
  $("#qaOut").innerHTML =
    "<h3 style=\"margin-bottom:.2rem\">AI 整理的答疑帖 · " + nowStr() + "</h3>" +
    '<p class="muted">依据匿名区 ' + list.length + " 条反馈的热度，AI 归并出以下 " + picks.length + " 个高频问题（演示：本地规则库生成）。</p>" +
    picks.map((p, i) => '<div style="border-top:1px solid var(--line);padding-top:.7rem;margin-top:.7rem">' +
      "<h4 style=\"margin:.2rem 0\">Q" + (i + 1) + "：" + esc(p.q) + "</h4>" +
      '<p style="margin:0;color:var(--ink-2);font-size:.95rem">' + esc(p.a) + "</p></div>").join("") +
    '<p class="muted" style="margin-top:.8rem">说明：以上内容由规则库模拟生成，仅用于科普演示，不构成医疗、法律或投资建议。</p>';
  toast("已生成答疑帖");
}
$("#genQA").addEventListener("click", genQA);
$("#genQADemo").addEventListener("click", () => { getFb(); renderFb(); genQA(); });

const FAQ = [
  { q: "AI 会取代我的工作吗？", a: "更常见的变化是「会用 AI 的人」提升效率。与其担心被替代，不如把自己擅长的判断力、沟通与现场经验，和 AI 的检索与生成能力组合起来。" },
  { q: "免费 AI 工具为什么免费？", a: "多数是「基础功能免费 + 高级功能付费」或用免费额度换取用户规模。使用前看清隐私条款与数据用途，敏感内容不要上传。" },
  { q: "老人学不会是不是就不用了？", a: "不是。适老化改造的目标是把门槛降下来：大字号、少按钮、语音输入、保留人工窗口。学不会往往不是人的问题，是产品设计的问题。" },
  { q: "孩子用 AI 会不会不动脑筋了？", a: "关键在使用方式：让 AI 提问而不是直接给答案，读完让孩子复述、改编结局。家长陪同 + 限时 + 内容分级，比单纯禁止更有效。" },
  { q: "AI 生成的内容能直接发吗？", a: "发布前做三件事：核对事实与数据、检查是否涉及他人肖像或版权素材、按要求标注 AI 辅助情况。AI 是初稿，责任在人。" }
];
$("#faqList").innerHTML = FAQ.map((f) =>
  "<details class=\"acc\"><summary>" + esc(f.q) + "</summary><div class=\"body\">" + esc(f.a) + "</div></details>").join("");



  renderFb();}

function initEthics() {/* =========================================================
   8. 板块 06 · 伦理科普 + 自测
   ========================================================= */
const ETHICS = [
  { t: "AI 的使用边界", body: "AI 适合做「参谋」：整理资料、生成初稿、提供思路。不适合做「裁判」：不能替你做医疗诊断、法律定性、投资决定和学业评价。越是关键决策，越要保留人的判断与复核。" },
  { t: "个人信息保护", body: "三层防护：① 不上传——身份证、银行卡、验证码、病历原件、涉密资料；② 去标识——发图前打码、删定位、去姓名；③ 看条款——确认数据是否被用于训练、能否删除。儿童信息一律不采集。" },
  { t: "理性合规使用", body: "作业与作品按要求标注 AI 使用情况；不生成虚假新闻、伪造证件与换脸视频；不使用未授权素材；不把 AI 输出当作权威来源直接引用。" },
  { t: "常见风险清单", body: "幻觉编造（看似合理的假信息）· 算法偏见（训练数据带来的刻板印象）· 过度依赖（思考能力退化）· 信息茧房（只看得到同类观点）· 成瘾设计（无限下滑与推送）。对策：交叉验证、主动接触不同观点、限定使用时长。" },
  { t: "科技向善的三条底线", body: "有益——解决真实民生问题；无害——不伤害弱势群体、不制造骗局；可控——保留人工渠道与退出机制。技术普惠的终点，是不让任何一个人被落在屏幕外面。" }
];
$("#ethicsList").innerHTML = ETHICS.map((e, i) =>
  "<details class=\"acc\"" + (i === 0 ? " open" : "") + "><summary>" + esc(e.t) + "</summary><div class=\"body\">" + esc(e.body) + "</div></details>").join("");

const QUIZ = [
  { q: "用 AI 查体检报告，最合适的做法是？", o: ["完全按 AI 的结论吃药","把 AI 的解释当成与医生沟通的草稿","把报告原图发到公开群求解答","让 AI 直接开处方"], a: 1, why: "AI 不能诊断与开药；报告常含敏感信息，不应公开发原图。" },
  { q: "视频通话里“熟人”要求转账，你应该？", o: ["立刻转，视频里确实是他","挂断后用原号码回拨并做随机动作验证","按对方要求开启屏幕共享","先转一半试试"], a: 1, why: "AI 换脸与拟声可伪造熟人脸与声音；回拨 + 随机动作是最简单的核验。" },
  { q: "以下哪项信息可以发给公共 AI？", o: ["家人的身份证号","公司涉密项目资料","一段自己写的作文草稿","银行卡号与验证码"], a: 2, why: "证件号、涉密资料、银行卡与验证码都属于严禁上传的信息。" },
  { q: "课程作业用 AI 辅助，正确做法是？", o: ["直接用 AI 生成整篇提交","按老师要求标注 AI 使用情况并自行改写","把 AI 输出署自己的名当作原创","让 AI 替你参加在线考试"], a: 1, why: "AI 是工具不是作者；标注与真实表达是学术诚信的底线。" },
  { q: "关于“适老化”，下列说法正确的是？", o: ["老人学不会是老人的问题","产品应提供大字、语音与人工窗口","取消线下窗口可倒逼老人学习","验证码越复杂越安全"], a: 1, why: "适老化改造的核心是降低门槛、保留人工渠道，而不是把人挡在门外。" }
];
function renderQuiz() {
  $("#quizBox").innerHTML = QUIZ.map((q, i) =>
    '<fieldset style="margin-bottom:.8rem"><legend>第 ' + (i + 1) + " 题：" + esc(q.q) + "</legend>" +
    q.o.map((op, j) => '<label class="radio"><input type="radio" name="qz' + i + '" value="' + j + '"> ' + esc(op) + "</label>").join("") +
    "</fieldset>").join("");
}
renderQuiz();
$("#quizForm").addEventListener("submit", (e) => {
  e.preventDefault();
  let score = 0, miss = [];
  QUIZ.forEach((q, i) => {
    const picked = $("input[name='qz" + i + "']:checked");
    if (picked && +picked.value === q.a) score++; else miss.push("第 " + (i + 1) + " 题：" + q.why);
  });
  const box = $("#quizResult"); box.hidden = false;
  box.innerHTML = "<b>得分：" + score + " / " + QUIZ.length + "</b>" +
    (score === QUIZ.length ? " —— 全对！你已经具备很好的 AI 素养。" : " —— 看看这几条：") +
    (miss.length ? "<ul style=\"margin:.4rem 0 0;padding-left:1.1rem\">" + miss.map((m) => "<li>" + esc(m) + "</li>").join("") + "</ul>" : "");
  box.scrollIntoView({ block: "nearest" });
});
$("#quizAgain").addEventListener("click", () => {
  QUIZ.forEach((q, i) => { const c = $("input[name='qz" + i + "']:checked"); if (c) c.checked = false; });
  $("#quizResult").hidden = true; renderQuiz(); toast("已重置，可以再答一次");
});


}

function initTools() {/* =========================================================
   9. 板块 07 · 免费 AI 工具导航
   ========================================================= */
const TOOLS = [
  { n: "讯飞星火", s: "语音助手", p: "网页 / App", f: "基础功能免费", h: "中文语音输入与朗读准确，适合打字不便的长辈。", c: "高级功能与更高额度需付费，以官方说明为准。" },
  { n: "豆包", s: "语音助手", p: "网页 / App", f: "基础功能免费", h: "对话自然，支持语音问答、图片理解与日常陪聊。", c: "不要上传含个人证件的图片；注意隐私条款。" },
  { n: "微信「关怀模式 + 语音转文字」", s: "语音助手", p: "App 内置", f: "免费", h: "系统级大字号与语音输入，长辈最常用的一条通路。", c: "需在「设置—关怀模式」中开启；部分旧机型入口不同。" },
  { n: "手机自带的识图 / 识物（系统相册）", s: "拍照识物", p: "手机系统", f: "免费", h: "识别花草、商品、文字提取，数据可留在本地处理。", c: "不同品牌名称不同（如「智慧视觉」「识屏」）。" },
  { n: "形色（识花）", s: "拍照识物", p: "App", f: "基础功能免费", h: "拍照识别植物，适合亲子自然教育与老人养花。", c: "识别结果仅供参考，不采食不明植物。" },
  { n: "微信「提取文字」小程序", s: "文本纠错", p: "小程序", f: "免费", h: "拍照提取印刷文字、表格转文本，社区通知看得清。", c: "手写体识别率有限，重要文件请人工核对。" },
  { n: "文心一言", s: "文本纠错", p: "网页 / App", f: "基础功能免费", h: "中文改写、润色、错别字检查与公文格式建议。", c: "专业文本仍需人工复核，勿上传涉密内容。" },
  { n: "通义", s: "写作学习", p: "网页 / App", f: "基础功能免费", h: "长文总结、会议纪要、学习路径规划。", c: "导出与高级模型可能需登录或付费。" },
  { n: "Kimi 智能助手", s: "写作学习", p: "网页 / App", f: "基础功能免费", h: "长文档阅读与要点提炼，适合论文资料整理。", c: "不要上传未公开的原创稿件与涉密资料。" },
  { n: "国家智慧教育公共服务平台", s: "学习教育", p: "网页", f: "免费（官方）", h: "官方权威课程与资源，覆盖基础教育与终身学习。", c: "需实名登录；认准官方域名，谨防仿冒站点。" },
  { n: "国家医保服务平台（智能客服）", s: "健康医疗", p: "App / 小程序", f: "免费（官方）", h: "查参保、查药品目录、问办事流程，官方口径可靠。", c: "涉及报销与待遇以当地经办机构答复为准。" },
  { n: "医院官方小程序（AI 导诊 + 预约）", s: "健康医疗", p: "小程序", f: "免费（官方）", h: "症状自查 → 推荐科室 → 直接预约，减少排错队。", c: "认准医院官方认证标识，勿通过第三方付费代挂号。" },
  { n: "高德地图（语音导航 / 无障碍出行）", s: "出行办事", p: "App", f: "基础功能免费", h: "语音播报、公交到站提醒、无障碍设施标注。", c: "出行导航注意耗电与流量，长辈出行建议家人同行。" },
  { n: "剪映（AI 字幕 / 一键成片）", s: "创作辅助", p: "App / 桌面", f: "基础功能免费", h: "自动识别语音生成字幕，家庭视频也能配上字幕。", c: "部分素材与高级功能需会员，导出留意水印设置。" },
  { n: "美图秀秀（AI 老照片修复）", s: "图像修复", p: "App", f: "部分功能免费", h: "一键上色、去划痕，适合家庭老照片数字化。", c: "涉及家人肖像请先取得同意；清晰度提升有限。" },
  { n: "国家反诈中心 App", s: "反诈安全", p: "App", f: "免费（官方）", h: "来电预警、身份核实、可疑线索举报。", c: "开启来电预警需授权；不代替报警，遇骗及时拨打 96110。" }
];
let toolCat = "全部";
function renderToolCats() {
  const cats = ["全部"].concat(TOOLS.map((t) => t.s).filter((v, i, a) => a.indexOf(v) === i));
  $("#toolCats").innerHTML = cats.map((c) =>
    '<button class="tab" role="tab" aria-selected="' + (c === toolCat) + '" data-cat="' + esc(c) + '">' + esc(c) + "</button>").join("");
  bindTabs($("#toolCats"), "data-cat", (v) => { toolCat = v; renderToolCats(); renderTools(); });
}
function renderTools() {
  const q = ($("#toolSearch").value || "").trim();
  const list = TOOLS.filter((t) => (toolCat === "全部" || t.s === toolCat) &&
    (!q || (t.n + t.s + t.h + t.p).indexOf(q) > -1));
  $("#toolList").innerHTML = list.length ? list.map((t) =>
    '<article class="tool"><div class="top"><h3>' + esc(t.n) + '</h3><span class="scene">' + esc(t.s) + "</span>" +
    '<span class="pill">' + esc(t.f) + "</span></div>" +
    '<dl class="kv"><dt>平台</dt><dd>' + esc(t.p) + "</dd><dt>亮点</dt><dd>" + esc(t.h) + "</dd><dt>注意</dt><dd>" + esc(t.c) + "</dd></dl></article>").join("") +
    '<div class="empty" style="grid-column:1/-1">收录标准：国内可用、基础功能免费、无强制开屏广告。<b>本页为科普展示，不构成推荐或背书</b>；免费额度与功能会调整，实际请以各平台官方说明为准。凡要求付费、开通会员才能使用的功能，请先核实是否官方渠道。</div>'
    : '<div class="empty" style="grid-column:1/-1">没有匹配的工具，换个关键词试试。</div>';
}
$("#toolSearch").addEventListener("input", renderTools);
renderToolCats(); renderTools();


}

function initPitfall() {/* =========================================================
   10. 板块 08 · 避雷指南
   ========================================================= */
const ICO = {
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v6c0 4.2-2.9 7.6-7 9-4.1-1.4-7-4.8-7-9V6z"/><path d="M9 12l2 2 4-4"/></svg>',
  paper: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/></svg>',
  wallet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10.5h18"/><circle cx="17" cy="15" r="1.1" fill="currentColor" stroke="none"/></svg>'
};
const PIT = [
  { t: "AI 换脸 / 拟声诈骗识别", icon: ICO.shield,
    pts: ["视频里的人也可能是合成的：让对方侧脸、遮眼、做随机动作。",
      "听到熟人借钱先挂断，用你原本保存的号码回拨核实。",
      "凡提到「验证码、屏幕共享、安全账户、紧急保密」的，一律挂断。",
      "大额转账前与家人当面确认；可疑号码用国家反诈中心 App 举报。",
      "给家里长辈设一个「转账二次确认人」，把风险挡在流程里。"] },
  { t: "AI 假新闻 / 假图片辨别", icon: ICO.paper,
    pts: ["看来源：是否官方账号、是否有原始链接与发布时间。",
      "看细节：手指数量、文字错乱、光影方向不一致，多为 AI 生成。",
      "看情绪：标题极端煽动、催你转发的，先停下来查一查。",
      "反向搜图：用图片搜索找原图与最早出处。",
      "交叉验证：至少两个独立权威来源一致，再相信与转发。"] },
  { t: "付费套路防范", icon: ICO.wallet,
    pts: ["默认勾选的续费、试用到期自动扣费，开通前逐项取消。",
      "先用免费额度验证效果，再决定是否付费。",
      "不在小众站点绑定免密支付与大额银行卡。",
      "「不充值就不能用」的公共服务（挂号、政务）基本都是假的。",
      "保留截图与订单号，遇纠纷通过平台与消协渠道维权。"] }
];
$("#pitList").innerHTML = PIT.map((p) =>
  '<article class="card"><h3><span class="pico" aria-hidden="true">' + p.icon + "</span>" + esc(p.t) + "</h3>" +
  '<ul style="margin:.4rem 0 0;padding-left:1.1rem;font-size:.93rem;color:var(--ink-2)">' +
  p.pts.map((x) => "<li style=\"margin-bottom:.3rem\">" + esc(x) + "</li>").join("") + "</ul></article>").join("");


}

function initStories() {/* =========================================================
   11. 板块 09 · 故事电台
   ========================================================= */
const STORIES = [
  { no: "01", who: "李爷爷 78 岁 · 张奶奶 80 多岁", tag: "e", title: "体检搬到家门口，十分钟就完事",
    lines: [
      "以前我去做体检，得让儿子专门请假陪我去医院，来回就是大半天。",
      "现在下楼走几步就到了，十分钟做完，机器还提醒我「少吃盐、多散步」。",
      "张奶奶一开始站在门口不敢进，说怕弄坏了。工作人员讲了一遍，她当场就学会了。",
      "现在她每周都来，还拉着老姐妹一起。她说，这机器比去医院方便多了。"
    ],
    src: "全国中老年网《搭建数智康养场景 守护「银发生活」》，广西柳州春风社区数智康养中心。" },
  { no: "02", who: "肖奶奶 · 广西柳州市社会福利院", tag: "e", title: "有了「电子眼」，我敢用助行器了",
    lines: [
      "我腿脚不利索，最怕的就是摔了没人知道，所以那阵子干脆不肯动。",
      "后来院里装了能看出来人是不是要摔倒的摄像头。有一次我起身滑了一下，警报马上就响了。",
      "护理员很快就到了，信息还同步到了护士站，楼层里也播报了。",
      "现在不用她们劝，我自己按时去训练。护理员说，她们也终于能多坐下来陪我们说说话。"
    ],
    src: "全国中老年网同上。报道中还提到院方引入智能床垫监测睡眠、用手环追踪心率血压。" },
  { no: "03", who: "潘峥霖 · 湖南永州健康照护师", tag: "y", title: "离开职场多年后，我拿到了月薪 6000 的工作",
    lines: [
      "中间有几年没上班，再找工作时投出去的简历基本没回音，心里挺没底的。",
      "我在「永州发布」上看到政府在组织技能培训，就报了健康照护师的订单班。",
      "结业后我进了一家养老服务公司，给失能老人做生活护理，一个月 6000 块。",
      "手上有了过硬的手艺，工作稳定，日子也就一点点有奔头了。"
    ],
    src: "教育部网站《推动高质量充分就业取得新进展》（2026-08-10）。永州 2026 年上半年组织相关培训 1.1 万人次，5000 余人顺利就业。" },
  { no: "04", who: "一个小学三年级家庭 · 情景示例", tag: "k", title: "贴在冰箱上的那张「AI 使用公约」",
    lines: [
      "孩子写作业先问 AI，我们一开始只会喊「不许用」，越吵越僵。",
      "后来照着指南里的建议，一家三口坐下来，一起写了张公约贴在冰箱上。",
      "写清楚哪几类作业可以用、用到哪一步，每次用完要附上「我的思考轨迹」。",
      "还加了一条：AI 给的菜谱要真的下厨做一遍，AI 写的代码要自己跑一次。"
    ],
    src: "情景示例，依据北京市教委《北京市教育领域人工智能应用指南（2026 年）》与人民网《孩子写作业先问 AI，家长怎么办》（2026-09-03）整理，非具体人物采访。" }
];
let storyTimer = null;
$("#storyList").innerHTML = STORIES.map((s, i) =>
  '<article class="story" data-aud="' + (s.tag === "k" ? "kid" : s.tag === "y" ? "youth" : "elder") + '">' +
  '<div class="cover" aria-hidden="true"><span class="no">' + esc(s.no) + '</span><span class="wave">' +
  '<svg viewBox="0 0 64 44" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round">' +
  '<path d="M4 22h4M14 14v16M22 8v28M30 16v12M38 11v22M46 17v10M54 20v4"/></svg></span></div>' +
  '<div class="in"><span class="tag ' + (s.tag === "k" ? "t-kid" : s.tag === "y" ? "t-youth" : "t-elder") + '">' + esc(s.who) + "</span>" +
  "<h3 style=\"margin:.5rem 0 .3rem;font-size:1.05rem\">" + esc(s.title) + "</h3>" +
  '<div class="player"><div style="display:flex;gap:.5rem;flex-wrap:wrap">' +
  '<button class="btn btn-primary btn-sm playBtn" type="button" data-i="' + i + '">▶ 播放（模拟）</button>' +
  '<button class="btn btn-ghost btn-sm stopBtn" type="button">■ 停止</button></div>' +
  '<div class="bar"><i></i></div><p class="caption muted">点击下方播放，字幕会逐句推进。</p></div>' +
  '<p class="src"><b>出处：</b>' + esc(s.src) + "</p></div></article>").join("");
$$(".playBtn").forEach((b) => b.addEventListener("click", () => {
  const i = +b.getAttribute("data-i"), s = STORIES[i];
  const card = b.closest(".story"), bar = $(".bar i", card), cap = $(".caption", card);
  clearInterval(storyTimer); $$(".bar i").forEach((x) => (x.style.width = "0"));
  let k = 0;
  cap.textContent = s.lines[0];
  bar.style.width = "8%";
  storyTimer = setInterval(() => {
    k++;
    if (k >= s.lines.length) { clearInterval(storyTimer); bar.style.width = "100%"; cap.textContent = "—— 故事结束 ·（演示播放，无真实音频）"; return; }
    cap.textContent = s.lines[k]; bar.style.width = Math.round(((k + 1) / s.lines.length) * 100) + "%";
  }, 2400);
  toast("模拟播放中：本 Demo 不含真实音频文件");
}));
$$(".stopBtn").forEach((b) => b.addEventListener("click", () => {
  clearInterval(storyTimer); $$(".bar i").forEach((x) => (x.style.width = "0"));
  const cap = $(".caption", b.closest(".story")); if (cap) cap.textContent = "已停止播放。";
}));


}

function initSociety() {/* =========================================================
   12. 板块 10 · AI 社会发展
   ========================================================= */
const SOC = {
  med: [
    { t: "智能预约与导诊", d: "症状自查推荐科室、分时段预约、检查提醒，平均候诊时间下降。", tag: "e" },
    { t: "影像辅助阅片", d: "AI 标记可疑区域供医生复核，提升早筛效率；最终结论由医生签署。", tag: "e" },
    { t: "慢病随访", d: "血压血糖数据自动归档，异常触发社区随访与用药提醒。", tag: "e" },
    { t: "医保智能客服", d: "7×24 回答参保、报销、异地就医等高频问题，减少窗口排队。", tag: "e" }
  ],
  traffic: [
    { t: "信号配时优化", d: "按实时车流调整红绿灯，主干道通行效率提升、怠速排放下降。", tag: "y" },
    { t: "无障碍出行导航", d: "标注坡道、电梯与盲道，为轮椅与视障人士规划路线。", tag: "e" },
    { t: "公交到站预测", d: "结合路况预测到站时间，站台屏与手机同步，减少盲目等待。", tag: "e" },
    { t: "事故与应急识别", d: "视频巡检自动识别异常事件并派单，缩短响应时间。", tag: "y" }
  ],
  edu: [
    { t: "国家智慧教育平台", d: "优质课程资源城乡共享，支持离线下载与大字模式。", tag: "k" },
    { t: "AI 分层练习", d: "按学生掌握情况推送不同难度练习，教师从批改中解放出来。", tag: "k" },
    { t: "口语与发音陪练", d: "即时反馈发音与语调，偏远地区也能获得练习机会。", tag: "y" },
    { t: "特殊教育辅助", d: "语音转文字、字幕生成，帮助听障与阅读障碍学生跟上课堂。", tag: "e" }
  ]
};
function renderSoc(k) {
  $("#socList").innerHTML = (SOC[k] || []).map((x) =>
    '<article class="card" data-aud="' + (x.tag === "k" ? "kid" : x.tag === "y" ? "youth" : "elder") + '">' +
    "<h3>" + esc(x.t) + '</h3><p style="margin:0;font-size:.93rem;color:var(--ink-2)">' + esc(x.d) + "</p></article>").join("");
}
tabGroup(".tabs[aria-label='公共服务领域']", "data-soc", renderSoc);



  renderSoc("med");}

function initHeritage() {/* =========================================================
   13. 板块 11 · 非遗体验馆
   ========================================================= */
/* 13.1 老照片修复对比 */
const cmpRange = $("#cmpRange"), cmpHandle = $("#cmpHandle");
const beforeLayer = $(".before", $("#cmp"));
function syncCmp(v) { beforeLayer.style.clipPath = "inset(0 " + (100 - v) + "% 0 0)"; cmpHandle.style.left = v + "%"; }
cmpRange.addEventListener("input", () => syncCmp(+cmpRange.value));
syncCmp(50);

/* 13.2 纹样生成 */
const pc = $("#patternCanvas"), ctx = pc.getContext("2d");
const PAL = { red: ["#C0392B", "#E8A87C", "#F6D8C6", "#8E3A1C"], blue: ["#1F4E79", "#5B8DB8", "#CFE0EC", "#123A5A"], green: ["#2E7D6E", "#7FB3A5", "#DCEDE8", "#1D574C"], gold: ["#B8860B", "#D9B26A", "#F3E3C0", "#7A5300"] };
function drawPattern(seed) {
  const petals = +$("#ptPetals").value, layers = +$("#ptLayers").value, pal = PAL[$("#ptColor").value] || PAL.red;
  const W = pc.width, C = W / 2;
  ctx.clearRect(0, 0, W, W);
  ctx.fillStyle = "#FFFDF8"; ctx.fillRect(0, 0, W, W);
  const rnd = (function (s) { return function () { s = (s * 9301 + 49297) % 233280; return s / 233280; }; })(seed || 12345);
  for (let L = layers; L >= 1; L--) {
    const r = C * (0.22 + 0.16 * L) * (0.85 + rnd() * 0.3);
    const col = pal[(L - 1) % pal.length];
    ctx.save(); ctx.translate(C, C);
    for (let i = 0; i < petals; i++) {
      ctx.save(); ctx.rotate((Math.PI * 2 * i) / petals + (L % 2 ? Math.PI / petals : 0));
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(r * 0.45, -r * 0.42, r, 0);
      ctx.quadraticCurveTo(r * 0.45, r * 0.42, 0, 0);
      ctx.fillStyle = col; ctx.globalAlpha = 0.85; ctx.fill();
      ctx.globalAlpha = 1; ctx.strokeStyle = pal[pal.length - 1]; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.restore();
    }
    ctx.restore();
  }
  ctx.beginPath(); ctx.arc(C, C, C * 0.12, 0, Math.PI * 2);
  ctx.fillStyle = pal[pal.length - 1]; ctx.fill();
  ctx.beginPath(); ctx.arc(C, C, C * 0.94, 0, Math.PI * 2);
  ctx.strokeStyle = pal[pal.length - 1]; ctx.lineWidth = 2; ctx.stroke();
}
$("#ptPetals").addEventListener("input", () => { $("#ptPetalsV").textContent = $("#ptPetals").value; drawPattern(); });
$("#ptLayers").addEventListener("input", () => { $("#ptLayersV").textContent = $("#ptLayers").value; drawPattern(); });
$("#ptColor").addEventListener("change", drawPattern);
$("#ptGen").addEventListener("click", () => drawPattern(Math.floor(Math.random() * 90000) + 1000));
$("#ptSave").addEventListener("click", () => {
  try {
    const a = document.createElement("a");
    a.href = pc.toDataURL("image/png"); a.download = "传统纹样-" + Date.now() + ".png"; a.click();
    toast("已保存纹样图片");
  } catch (e) { toast("当前浏览器不支持直接保存，请右键图片另存为"); }
});
drawPattern(20260);

/* 13.3 方言配音（语音合成演示） */
$("#dlRate").addEventListener("input", () => { $("#dlRateV").textContent = (+$("#dlRate").value / 100).toFixed(1); });
$("#dlPitch").addEventListener("input", () => { $("#dlPitchV").textContent = (+$("#dlPitch").value / 100).toFixed(1); });
$("#dlPlay").addEventListener("click", () => {
  if (!("speechSynthesis" in window)) { toast("当前浏览器不支持语音朗读"); return; }
  const u = new SpeechSynthesisUtterance($("#dlText").value);
  u.lang = "zh-CN"; u.rate = +$("#dlRate").value / 100; u.pitch = +$("#dlPitch").value / 100;
  speechSynthesis.cancel(); speechSynthesis.speak(u);
  toast("演示朗读中（普通话音色，真实方言需方言语音库）");
});
$("#dlStop").addEventListener("click", () => { if ("speechSynthesis" in window) speechSynthesis.cancel(); });


}

function initQuest() {/* =========================================================
   14. 板块 12 · 闯关实践 + 徽章
   ========================================================= */
const QUESTS = {
  elder: [
    { id: "e1", t: "用官方小程序挂一次号", d: "在医院官方小程序完成一次预约挂号（或陪家中长辈完成一次），全程不使用第三方付费代挂。", b: "挂", name: "就医无忧" },
    { id: "e2", t: "开启大字朗读模式", d: "把手机或本网站切换到大字模式，并用语音朗读功能听一段内容。", b: "朗", name: "看得清楚" },
    { id: "e3", t: "完成一次反诈核验", d: "接到疑似熟人借钱的信息时，挂断并用原号码回拨核实；在匿名区分享你的经历。", b: "盾", name: "防骗卫士" }
  ],
  youth: [
    { id: "y1", t: "让 AI 改一版简历/自述", d: "用 AI 优化一段个人经历，核对数据真实性后保存，并标注 AI 辅助情况。", b: "简", name: "求职提能" },
    { id: "y2", t: "用 AI 生成一张公益海报", d: "确定主题色与文案，生成 3 版构图并选定一版，替换为可商用素材。", b: "设", name: "创意设计" },
    { id: "y3", t: "做一次事实核查", d: "找一条 AI 给出的专业结论，用两个独立权威来源交叉验证，记录差异。", b: "核", name: "求真核查" }
  ],
  parent: [
    { id: "p1", t: "用 AI 生成一幅亲子创意画", d: "和孩子一起确定主题，用 AI 生成创意图，再由孩子手绘补充一部分。", b: "画", name: "创意亲子" },
    { id: "p2", t: "完成一轮 AI 科普问答", d: "向 AI 提一个孩子的「十万个为什么」，与孩子一起验证答案是否正确。", b: "问", name: "好奇探索" },
    { id: "p3", t: "做一次家庭安全筛查", d: "用 AI 检查家中儿童安全隐患（药品、尖锐角、清洁剂），并完成整改。", b: "安", name: "安全守护" }
  ]
};
const ALL_TASKS = QUESTS.elder.concat(QUESTS.youth, QUESTS.parent);
let done = store.get("questDone", {});
let curQ = "elder";
function badgeSVG(ch, got) {
  return '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="26" r="19" fill="' + (got ? "var(--gold)" : "#C9BFAF") + '"/>' +
    '<circle cx="32" cy="26" r="14" fill="none" stroke="#fff" stroke-width="1.6" opacity=".8"/>' +
    '<text x="32" y="33" text-anchor="middle" font-size="16" font-weight="700" fill="#fff" font-family="sans-serif">' + ch + "</text>" +
    '<path d="M22 40 L18 60 L32 52 L46 60 L42 40 Z" fill="' + (got ? "var(--orange)" : "#D6CFC5") + '"/></svg>';
}
function renderQuests() {
  $("#qTasks").innerHTML = (QUESTS[curQ] || []).map((t) => {
    const ok = !!done[t.id];
    return '<article class="task' + (ok ? " done" : "") + '"><span class="tick" aria-hidden="true">✓</span>' +
      '<div style="flex:1"><h4>' + esc(t.t) + '</h4><p>' + esc(t.d) + "</p></div>" +
      (ok ? '<span class="pill" style="align-self:center">已打卡</span>'
          : '<button class="btn btn-primary btn-sm qBtn" type="button" data-id="' + t.id + '" style="align-self:center">完成打卡</button>') +
      "</article>";
  }).join("");
  $$(".qBtn").forEach((b) => b.addEventListener("click", () => {
    const id = b.getAttribute("data-id");
    done[id] = true; store.set("questDone", done);
    const meta = ALL_TASKS.filter((x) => x.id === id)[0];
    renderAll(); toast("打卡成功，解锁徽章：「" + (meta ? meta.name : "") + "」");
  }));
}
function renderBadges() {
  const total = ALL_TASKS.length, got = ALL_TASKS.filter((t) => done[t.id]).length;
  $("#badgeWall").innerHTML = ALL_TASKS.map((t) => {
    const ok = !!done[t.id];
    return '<div class="badge' + (ok ? " got" : "") + '">' + badgeSVG(t.b, ok) + "<b>" + esc(t.name) + "</b>" +
      "<span>" + (ok ? "已解锁" : "未解锁") + "</span></div>";
  }).join("") + (function () {
    const all = got === total;
    return '<div class="badge' + (all ? " got" : "") + '">' + badgeSVG("全", all) + "<b>全龄友好使者</b><span>" +
      (all ? "已解锁" : "集齐 " + total + " 枚解锁") + "</span></div>";
  })();
}
function renderProgress() {
  const total = ALL_TASKS.length, got = ALL_TASKS.filter((t) => done[t.id]).length;
  const pct = total ? Math.round((got / total) * 100) : 0;
  $("#qProgressText").textContent = "总进度 " + got + "/" + total + "（" + pct + "%）";
  $("#qBar").style.width = pct + "%";
  $("#qBarWrap").setAttribute("aria-valuenow", String(pct));
}
function renderAll() { renderQuests(); renderBadges(); renderProgress(); }
tabGroup(".tabs[aria-label='闯关分组']", "data-q", (v) => { curQ = v; renderQuests(); });
$("#qReset").addEventListener("click", () => { done = {}; store.set("questDone", done); renderAll(); toast("闯关进度已重置"); });



  renderAll();}

function initAmbassador() {/* =========================================================
   15. 板块 13 · 体验官计划
   ========================================================= */
const SEED_AMB = [
  { type: "老年体验官", name: maskName("王桂芳"), product: "手机语音助手", text: "希望语音助手能听懂我的方言，按钮再大一点。", t: "示例" },
  { type: "亲子体验官", name: maskName("陈小雨"), product: "儿童故事机", text: "希望默认关闭个性化推荐，并加上单次使用时长的护眼提醒。", t: "示例" },
  { type: "青年体验官", name: maskName("赵一鸣"), product: "AI 简历工具", text: "希望润色时提示哪些表述可能存在夸大风险。", t: "示例" }
];
function getAmb() { return store.get("amb", null) || SEED_AMB.slice(); }
function renderAmb() {
  const list = getAmb();
  $("#ambTotal").textContent = list.length;
  $("#ambList").innerHTML = list.map((a) =>
    '<article class="post"><div class="meta"><span class="who">' + esc(a.name) + "</span>" +
    '<span class="tag ' + (a.type.indexOf("亲子") > -1 ? "t-kid" : a.type.indexOf("青年") > -1 ? "t-youth" : "t-elder") + '">' + esc(a.type) + "</span>" +
    "<span>" + esc(a.t) + "</span></div>" +
    '<p><b>想测评：</b>' + esc(a.product) + "<br><b>改进建议：</b>" + esc(a.text) + "</p></article>").join("");
}
$("#ambForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const type = ($("input[name='ambType']:checked") || {}).value || "亲子体验官";
  const list = getAmb();
  const r = filterText($("#ambText").value.trim() || "（未填写具体建议）");
  list.unshift({ type: type, name: maskName($("#ambName").value), product: $("#ambProduct").value.trim() || "待定", text: r.text, t: "刚刚" });
  store.set("amb", list);
  $("#ambName").value = ""; $("#ambProduct").value = ""; $("#ambText").value = "";
  renderAmb(); toast(r.hit ? "报名成功（已自动隐藏敏感信息）" : "报名成功，欢迎加入体验官计划");
});
renderAmb();


}
/* =========================================================
   16. 三大主线视角切换 + 导航高亮
   ========================================================= */
const LINE_NAME = { kid: "幼儿启蒙", youth: "青年成长", elder: "老年保障" };
$$(".lbtn").forEach((b) => b.addEventListener("click", () => {
  const line = b.getAttribute("data-line");
  const on = b.getAttribute("aria-pressed") === "true";
  $$(".lbtn").forEach((x) => x.setAttribute("aria-pressed", "false"));
  if (on) { clearFocus(); return; }
  b.setAttribute("aria-pressed", "true");
  document.body.setAttribute("data-focus-aud", line);
  $$("[data-aud]").forEach((el) => el.classList.toggle("aud-on", el.getAttribute("data-aud") === line));
  $("#focusNote").hidden = false;
  $("#focusNoteText").textContent = "已切换到「" + LINE_NAME[line] + "」视角，相关内容已高亮：";
  toast("已切换到「" + LINE_NAME[line] + "」视角");
}));
function clearFocus() {
  document.body.removeAttribute("data-focus-aud");
  $$("[data-aud]").forEach((el) => el.classList.remove("aud-on"));
  $("#focusNote").hidden = true;
}
$("#clearFocus").addEventListener("click", clearFocus);

const navLinks = $$("#nav a");
/* 多页面版本：导航高亮在 boot() 中按当前页路径处理，这里不再用滚动监听 */


/* =========================================================
   17. 真实视频资料馆（中央广播电视总台央视网《智能中国》六集）
   标题 / 简介 / 封面 / 单集页均取自央视网节目单，点播流为央视网点播接口返回地址。
   本站不存储视频文件；播放需联网，封面与文字资料已本地化，断网可看。
   ========================================================= */
const VIDEOS = [
  { key: "traffic", short: "智能交通", tag: "智能交通 · 公共服务",
    title: "《智能中国》 20220506 智能交通", date: "2022-05-06", channel: "CCTV-10 科教",
    brief: "人的流动、物的流动体现了一个社会经济体的活力。中国的铁路网每年搭载乘客达到 20 亿人次以上；中国的公路网每年流通货物超过四百亿吨。智慧交通正显现巨大的变革力量。",
    img: "./assets/img/v-traffic.jpg",
    hls: "https://newcntv.qcloudcdn.com/asp/hls/main/0303000a/3/default/64008c142d294b5cb740ee242b2e3407/main.m3u8?maxbr=2048",
    page: "https://tv.cctv.com/2023/06/25/VIDE65IlRmZccB4a2l49Tc3o230625.shtml" },
  { key: "med", short: "智慧医疗", tag: "智慧医疗 · 老年保障",
    title: "《智能中国》 20220507 智慧医疗", date: "2022-05-07", channel: "CCTV-10 科教",
    brief: "中国，一个超过 14 亿人口的大国，应该如何解决医疗资源的匮乏？以物联网、云计算、大数据、5G 为代表的新一代信息技术正在推动智慧医疗的高速发展，成为应对的良方。",
    img: "./assets/img/v-med.jpg",
    hls: "https://newcntv.qcloudcdn.com/asp/hls/main/0303000a/3/default/eb6926798dda47e583d26d7f4137ec47/main.m3u8?maxbr=2048",
    page: "https://tv.cctv.com/2022/05/07/VIDEeI5aHygeVyikTqISifVv220507.shtml" },
  { key: "edu", short: "智慧教育", tag: "智慧教育 · 青年成长",
    title: "《智能中国》 20220508 智慧教育", date: "2022-05-08", channel: "CCTV-10 科教",
    brief: "人类社会的发展离不开科技和教育的进步。人工智能所代表的新一代信息技术将会对教育理念产生巨大影响，智能装备从产业延伸到教学，让学以致用成为常态。",
    img: "./assets/img/v-edu.jpg",
    hls: "https://newcntv.qcloudcdn.com/asp/hls/main/0303000a/3/default/f8b963e56776420a942c70f9116f18ec/main.m3u8?maxbr=2048",
    page: "https://tv.cctv.com/2022/05/08/VIDE3u3Arsxqz2n66ZWhJ9rp220508.shtml" },
  { key: "home", short: "智慧家园", tag: "智慧家园 · 全龄生活",
    title: "《智能中国》 20220509 智慧家园", date: "2022-05-09", channel: "CCTV-10 科教",
    brief: "世界在变，人们不经意的生活细节正在慢慢改变：居所、城市、旅途、沟通交往、消费娱乐，甚至宠物的小小安乐窝，都成为智能化设备的舞台。",
    img: "./assets/img/v-home.jpg",
    hls: "https://newcntv.qcloudcdn.com/asp/hls/main/0303000a/3/default/2e0c682cf8db4136ad4f87eae9bae7b6/main.m3u8?maxbr=2048",
    page: "https://tv.cctv.com/2022/05/09/VIDEpAB6TaQX5qibLKS025wm220509.shtml" },
  { key: "city", short: "智慧城市", tag: "智慧城市 · 公共服务",
    title: "《智能中国》 20220510 智慧城市", date: "2022-05-10", channel: "CCTV-10 科教",
    brief: "城市是人类文明的载体，也是科技发展的摇篮。从最初的数字城市、互联网城市到现在的智慧城市，人工智能技术在城市的进化迭代进程中起到了至关重要的作用。",
    img: "./assets/img/v-city.jpg",
    hls: "https://newcntv.qcloudcdn.com/asp/hls/main/0303000a/3/default/6433c779935b4431bef84554221f3e5c/main.m3u8?maxbr=2048",
    page: "https://tv.cctv.com/2022/05/10/VIDENeJ8bY97B0vOKIgv9h2k220510.shtml" },
  { key: "make", short: "智造赋能", tag: "智造赋能 · 产业发展",
    title: "《智能中国》 20220512 智造赋能", date: "2022-05-12", channel: "CCTV-10 科教",
    brief: "中国制造遍及全球，但人工智能时代来临，制造业亟待转型。从电商到工业互联网，从冶金电力到新能源汽车、航天工业，中国制造正驱动从制造大国到智造强国的革新升级。",
    img: "./assets/img/v-make.jpg",
    hls: "https://newcntv.qcloudcdn.com/asp/hls/main/0303000a/3/default/e5afa8139367492197dea17fd61da3c1/main.m3u8?maxbr=2048",
    page: "https://tv.cctv.com/2022/05/12/VIDEz6h7PZEqpUwww14VEnYB220512.shtml" }
];
let hlsInst = null, curVideo = 0;

function selectVideo(i, autoplay) {
  const v = VIDEOS[i];
  if (!v || !HAS("#vidGrid")) return;
  curVideo = i;
  $$(".vidCard").forEach((c, n) => c.classList.toggle("cur", n === i));
  $("#vidNowTitle").textContent = v.title;
  $("#vidNowMeta").textContent = v.channel + " · " + v.date + " · 央视网公开点播";
  $("#vidMetaTitle").textContent = v.short;
  $("#vidMetaBrief").textContent = v.brief;
  $("#vidOpenCctv").setAttribute("href", v.page);
  const video = $("#videoPlayer");
  if (video) { video.poster = v.img; }
  $("#vidErr").hidden = true;
  if (autoplay) playVideo();
}

function playVideo() {
  const v = VIDEOS[curVideo], video = $("#videoPlayer"), err = $("#vidErr");
  if (!video || !err) return;
  err.hidden = true;
  $("#vidNowMeta").textContent = v.channel + " · 正在连接央视网点播流…";
  try {
    video.pause();
    if (hlsInst) { hlsInst.destroy(); hlsInst = null; }
    if (window.Hls && window.Hls.isSupported()) {
      hlsInst = new window.Hls({ enableWorker: true });
      hlsInst.loadSource(v.hls);
      hlsInst.attachMedia(video);
      hlsInst.on(window.Hls.Events.MANIFEST_PARSED, () => {
        $("#vidNowMeta").textContent = v.channel + " · 已就绪，可播放";
        video.play().catch(() => {});
      });
      hlsInst.on(window.Hls.Events.ERROR, (_, d) => {
        if (d && d.fatal) {
          err.hidden = false;
          $("#vidNowMeta").textContent = v.channel + " · 视频流载入失败（可改用央视原页面）";
        }
      });
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = v.hls;
      video.play().catch(() => {});
    } else {
      err.hidden = false;
    }
  } catch (e) {
    err.hidden = false;
  }
}

function initVideos() {
  if (!HAS("#vidGrid")) return;
  $("#vidGrid").innerHTML = VIDEOS.map((v, i) => `
    <article class="vidCard${i === 0 ? " cur" : ""}" data-vi="${i}">
      <img src="${v.img}" alt="央视《智能中国》${esc(v.short)}分集封面" loading="lazy">
      <div class="vcBody">
        <span class="vcTag">${esc(v.tag)}</span>
        <h4>${esc(v.title)}</h4>
        <p class="vcBrief">${esc(v.brief)}</p>
        <div class="vcFoot">
          <button type="button" class="btn btn-sm btn-primary" data-vi="${i}">选中这一集</button>
          <a class="btn btn-sm btn-ghost" href="${v.page}" target="_blank" rel="noopener noreferrer">央视原页面 ↗</a>
        </div>
      </div>
    </article>`).join("");
  $("#vidGrid").addEventListener("click", (e) => {
    if (e.target.closest("a")) return;
    const hit = e.target.closest("[data-vi]");
    if (hit) selectVideo(parseInt(hit.getAttribute("data-vi"), 10), false);
  });
  if (HAS("#vidPlay")) $("#vidPlay").addEventListener("click", () => playVideo());
  selectVideo(0, false);
}

/* =========================================================
   18. 分页面板：一页多主题，用标签切换，内容不挤在一条长滚动里
   ========================================================= */
const TAB_ALIAS = { qa: "feedback", pitfall: "tools" };
function activateTab(key, writeHash) {
  const bar = $(".tabbar");
  if (!bar) return false;
  const btns = $$(".tabbtn", bar), panes = $$(".tabpane");
  if (!btns.some((b) => b.getAttribute("data-tab") === key)) return false;
  btns.forEach((b) => b.setAttribute("aria-selected", String(b.getAttribute("data-tab") === key)));
  panes.forEach((p) => { p.hidden = p.getAttribute("data-tab") !== key; });
  if (writeHash) { try { history.replaceState(null, "", "#" + key); } catch (e) {} }
  return true;
}
(function initTabs() {
  if (!HAS(".tabbar")) return;
  let key = (location.hash || "").replace(/^#/, "");
  key = TAB_ALIAS[key] || key;
  if (!activateTab(key, false)) {
    const first = $(".tabbtn");
    if (first) activateTab(first.getAttribute("data-tab"), false);
  }
  window.addEventListener("hashchange", () => {
    let k = (location.hash || "").replace(/^#/, "");
    k = TAB_ALIAS[k] || k;
    if (k) activateTab(k, false);
  });
  $$(".tabbtn").forEach((b) => b.addEventListener("click", () => {
    activateTab(b.getAttribute("data-tab"), true);
    try {
      const top = $(".tabbar").getBoundingClientRect().top + window.pageYOffset - 6;
      window.scrollTo({ top: top, behavior: "smooth" });
    } catch (e) {}
  }));
})();

/* =========================================================
   19. 按页面调度（data-page 可空格分隔多个板块）
   ========================================================= */
const PAGE_INITS = {
  classroom: ["initClassroom"],
  cases: ["initHall"],
  community: ["initCommunity"],
  feedback: ["initFeedback"],
  ethics: ["initEthics"],
  tools: ["initTools", "initPitfall"],
  stories: ["initStories"],
  society: ["initSociety"],
  heritage: ["initHeritage"],
  quest: ["initQuest"],
  ambassador: ["initAmbassador"],
  videos: ["initVideos"],
  home: []
};
const INIT_MAP = { initClassroom: initClassroom, initHall: initHall, initCommunity: initCommunity,
  initFeedback: initFeedback, initEthics: initEthics, initTools: initTools, initPitfall: initPitfall,
  initStories: initStories, initSociety: initSociety, initHeritage: initHeritage, initQuest: initQuest,
  initAmbassador: initAmbassador, initVideos: initVideos };
(function boot() {
  const page = document.body.getAttribute("data-page") || "home";
  const list = [];
  page.split(/\s+/).forEach((pg) => {
    (PAGE_INITS[pg] || []).forEach((n) => { if (list.indexOf(n) < 0) list.push(n); });
  });
  list.forEach((n) => { try { INIT_MAP[n](); } catch (e) { if (window.console) console.error("模块初始化失败 " + n, e); } });
  /* 导航高亮 */
  const here = (location.pathname.split("/").pop() || "index.html");
  document.querySelectorAll("#nav a").forEach((a) => {
    const href = a.getAttribute("href");
    const on = href === here || (here === "" && href === "index.html") || (here === "index.html" && href === "index.html");
    if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  });
  if (store.get("firstVisit", true)) {
    setTimeout(() => { store.set("firstVisit", false); toast("提示：右上角 A+ 可放大字号，高对比度更护眼"); }, 1500);
  }
})();
})();
